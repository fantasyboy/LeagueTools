#pragma once
namespace Buffer
{
	char* GetName(DWORD obj);
	DWORD GetBufferCount(DWORD obj);
};

