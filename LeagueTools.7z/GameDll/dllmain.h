#pragma once

DWORD WINAPI ThreadProc(_In_ LPVOID lpParameter);